﻿using System.Web.Mvc;

namespace gushv3.Controllers
{
    public class ContactController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}