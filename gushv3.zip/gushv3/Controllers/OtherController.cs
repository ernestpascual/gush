﻿using System.Web.Mvc;


namespace gushv3.Controllers
{
    
    
    public class OtherController : Controller
    {
    }
}
