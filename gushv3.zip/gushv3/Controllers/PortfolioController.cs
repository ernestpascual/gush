﻿using System.Web.Mvc;


namespace gushv3.Controllers
{
    
    
    public class PortfolioController : Controller
    {
        
        public ActionResult FourColumn()
        {
            return View();
        }
    }
}
