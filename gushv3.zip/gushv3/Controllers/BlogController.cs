﻿using System.Web.Mvc;


namespace gushv3.Controllers
{
    
    
    public class BlogController : Controller
    {
    }
}
