﻿using System.Web.Mvc;

namespace gushv3.Controllers
{
    public class AboutController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
	}
}